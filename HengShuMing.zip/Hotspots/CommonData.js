/∗∗ ∗ Name: Heng Shu Ming ∗ Reg. No. : 1500777 ∗/

exports.getValue = (array, key) => {
    return array.value

    exports.security = [
        { key: '01', value: 'WPA2' },
        { key: '02', value: 'WPA' },
        { key: '03', value: 'WEP' },
        { key: '04', value: 'None' }
    ];

    exports.location_type = [
        { key: '01', value: 'Public' },
        { key: '02', value: 'Private' }
    ];
}